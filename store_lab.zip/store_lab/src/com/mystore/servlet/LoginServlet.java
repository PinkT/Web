package com.mystore.servlet;

import com.mystore.domian.User;
import com.mystore.util.JdbcUtil;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        //获取用户名和密码
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        //到数据库查询
        QueryRunner qr = new QueryRunner(JdbcUtil.getDataSource());
        String sql = "select * from user where username=? and password=?";
        User u = null;
        try {
            u = qr.query(sql, new BeanHandler<User>(User.class),username,password);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (u != null)
        {
            response.getWriter().write("登陆成功");
            //保存用户 到session中
            HttpSession session = request.getSession();
            session.setAttribute("user",u);
            //跳转到登录页面
            response.setHeader("refresh","1;url=/store_lab_war_exploded/index.jsp");
        }else{
            response.getWriter().write("登陆失败");
            response.setHeader("refresh","1;url=/store_lab_war_exploded/login.jsp");
        }

    }
}
