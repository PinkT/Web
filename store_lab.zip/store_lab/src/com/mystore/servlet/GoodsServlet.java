package com.mystore.servlet;

import com.mystore.domian.Goods;
import com.mystore.util.JdbcUtil;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/GoodsServlet")
public class GoodsServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        /**
         1.连接数据库
         2.从数据库当中获取数据
         3.把从数据库中取出的数据存放到request域当中
         4.转发到商品列表页面，转发时把request对象传入
         */
        // 1.连接数据库
         QueryRunner qr = new QueryRunner(JdbcUtil.getDataSource());
         // 2.从数据库当中获取数据
         String sql = "select * from goods";
         List<Goods> allGoods = null;
         try {
            allGoods = qr.query(sql, new BeanListHandler<Goods>(Goods.class));
         }catch (SQLException e)
         {
             e.printStackTrace();
         }
         System.out.println(allGoods);
         //3.把从数据库中取出的数据存放到request域当中
         req.setAttribute("allGoods", allGoods);
         // 4.转发到商品列表页面，转发时把request对象传入
         req.getRequestDispatcher("/goods_list.jsp").forward(req, resp);

}
}
