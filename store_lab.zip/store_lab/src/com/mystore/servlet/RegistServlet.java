package com.mystore.servlet;

import com.mystore.domian.User;
import com.mystore.util.JdbcUtil;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.dbutils.QueryRunner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
import java.util.UUID;

@WebServlet("/RegistServlet")
public class RegistServlet extends javax.servlet.http.HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        //获取form表单的参数，封装成User
        User u = new User();
        Map<String,String[]> parameterMap = request.getParameterMap();

        try {
            BeanUtils.populate(u,parameterMap);
        } catch (IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }
        //设置 用户id
        u.setId(UUID.randomUUID().toString());
        System.out.println(u);
        //写入数据库
        QueryRunner qr = new QueryRunner(JdbcUtil.getDataSource());
        //System.out.println(JdbcUtil.getDataSource());
        String sql = "insert into user value(?,?,?,?)";

        try {
            qr.update(sql,u.getId(),u.getUsername(),u.getPassword(),u.getPhone());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        response.setHeader("refresh","1;url=/store_lab_war_exploded/login.jsp");
    }
}
